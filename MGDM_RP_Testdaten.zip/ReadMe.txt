Minimales Geodatenmodell "Richtpl�ne der Kantone"
Mod�le de g�odonn�es minimal "Plans directeurs des cantons"


Testdaten f�r die Anh�rung
Donn�es test pour l'audition
============================


F�r die Anh�rung werden die Vektordaten der Kantone AG und SO als Geopackage-Datei 
sowie ein QGIS-Projekt mit der Darstellung gem�ss Darstellungsmodell zur Verf�gung gestellt. 
Bei den Daten handelt es sich um Testdaten der Kantone ohne rechtliche Wirkung. 
Die Zuordnung der Objekte zu den Themen wurde von den Kantonen verifiziert.

Pour l'audition, les donn�es vectorielles des cantons AG et SO sont fournies sous forme 
de fichier Geopackage et avec un projet QGIS comportant la repr�sentation conforme au mod�le
de repr�sentation. 
Les donn�es sont des donn�es test des cantons sans valeur juridique. 
L�attribution des objets aux th�mes a �t� v�rifi�e par les cantons.


Ausk�nfte / renseignements:
Rolf Giezendanner, rolf.giezendanner@are.admin.ch

